package com.mindtree.javaproject.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import com.mindtree.javaproject.entity.Employee;

public class Deserialization {
	
	public static void main(String[] args) throws IOException ,ClassNotFoundException{
		Employee emp=null;
		try {
		FileInputStream filein=new FileInputStream("D:\\FileHandling\\serial.txt");
		ObjectInputStream in=new ObjectInputStream(filein);
		emp=(Employee)in.readObject();
		in.close();
		filein.close();
		}
		finally {
			System.out.println("Deserializing employee..");
			System.out.println("Id of employee is"+emp.empId);
			System.out.println("Name of employee is"+emp.empName);
			System.out.println("Salary of employee is"+emp.empSalary);
		}
	}
}

