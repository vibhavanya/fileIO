package com.mindtree.javaproject.controller;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import com.mindtree.javaproject.entity.Employee;

public class Serialization {
	
	public static void main(String[] args) {
		
		Employee emp=new Employee();
		emp.empId=1;
		emp.empName="Juhi";
		emp.empSalary=20000;
		
		try {
		FileOutputStream fileout= new FileOutputStream("D:\\FileHandling\\serial.txt");
		ObjectOutputStream out=new ObjectOutputStream(fileout);
		out.writeObject(emp);
		out.close();
		fileout.close();
		System.out.println("serialized data is saved in char.txt file");
		}
	catch(IOException e){
		e.printStackTrace();
	}
		

}
}
