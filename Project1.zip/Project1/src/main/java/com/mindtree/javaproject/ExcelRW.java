package com.mindtree.javaproject;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;



class Employee{
	private int empId;
	private String empName;
	private int empSalary;
	public Employee() {
		super();
	}
	public Employee(int empId, String empName, int empSalary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(int empSalary) {
		this.empSalary = empSalary;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + "]";
	}
	
}	
public class ExcelRW {
	
	private static Workbook wb;
	private static Sheet sh;
	private static FileInputStream fis;
	private static FileOutputStream fos;
	private static Row row;
	private static Cell cell;

	public static void main(String[] args) throws EncryptedDocumentException, InvalidFormatException, IOException {
		
	fis=new FileInputStream("./rw.xlsx");
	wb=WorkbookFactory.create(fis);
	sh=wb.getSheet("Sheet1");
	int noOfRows=sh.getLastRowNum();
	System.out.println(noOfRows);
	Row header=sh.createRow(0);
	header.createCell(0).setCellValue("empId");
	header.createCell(1).setCellValue("empName");
	header.createCell(2).setCellValue("empSalary");
	List<Employee> employees=new ArrayList<>();
	employees.add(new Employee(1, "Aman", 20000));
	employees.add(new Employee(2, "Juhi", 30000));
	employees.add(new Employee(3, "Neha", 40000));
	int rowNo=1;
	for(Employee emp:employees) {
	row=sh.createRow(rowNo++);
	row.createCell(0).setCellValue(emp.getEmpId());
	row.createCell(1).setCellValue(emp.getEmpName());
	row.createCell(2).setCellValue(emp.getEmpSalary());
	}
	fos=new FileOutputStream("./rw.xlsx");
	wb.write(fos);
	fos.flush();
	fos.close();
	
	for(int i=0;i<=noOfRows;i++) {
	System.out.println(sh.getRow(i).getCell(0));
	System.out.println(sh.getRow(i).getCell(1));
	System.out.println(sh.getRow(i).getCell(2));
	}
	}
}